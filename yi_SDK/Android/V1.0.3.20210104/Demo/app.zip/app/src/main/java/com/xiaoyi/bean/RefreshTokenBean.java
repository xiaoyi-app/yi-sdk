package com.xiaoyi.bean;

import com.google.gson.annotations.Expose;

import java.io.Serializable;

public class RefreshTokenBean implements Serializable {

    /**
     * token : "d12b79f4-02b6-4429-817e-fda59f9f42f1"
     * expiresTime : 604800
     */
    @Expose
    private String token;
    @Expose
    private int expiresTime;

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public int getExpiresTime() {
        return expiresTime;
    }

    public void setExpiresTime(int expiresTime) {
        this.expiresTime = expiresTime;
    }
}
