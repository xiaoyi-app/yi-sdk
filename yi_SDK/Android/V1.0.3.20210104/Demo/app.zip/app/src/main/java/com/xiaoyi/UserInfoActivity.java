package com.xiaoyi;

import android.os.Bundle;
import android.widget.CompoundButton;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.xiaoyi.base.util.PreferenceUtil;
import com.xiaoyi.bean.UserListBean;
import com.xiaoyi.yicamerasdkcore.YiCameraSdk;

public class UserInfoActivity extends AppCompatActivity implements CompoundButton.OnCheckedChangeListener {

    private TextView name;
    private TextView url;
    private TextView app_id;
    private TextView open_id;
    private TextView token;
    private RadioButton fragment_way;
    private RadioButton activity_way;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_info);

        name=(TextView)findViewById(R.id.name);
        url=(TextView)findViewById(R.id.url);
        app_id=(TextView)findViewById(R.id.app_id);
        open_id=(TextView)findViewById(R.id.open_id);
        token=(TextView)findViewById(R.id.token);
        fragment_way=(RadioButton)findViewById(R.id.fragment_way);
        fragment_way.setOnCheckedChangeListener(this);
        activity_way=(RadioButton)findViewById(R.id.activity_way);
        activity_way.setOnCheckedChangeListener(this);

        UserListBean.RecordsBean mUserListBean = (UserListBean.RecordsBean)getIntent().getSerializableExtra(UserListActivity.BUNDLE_USER_BEAN);
        if (mUserListBean != null){
            name.setText("name: \n" + mUserListBean.getNickName());
            if (YiCameraSdk.URL.equals(YiCameraSdk.RELEASE_URL))
                url.setText("url: release \n" + YiCameraSdk.URL);
            else
                url.setText("url: debug \n" + YiCameraSdk.URL);
            app_id.setText("app_id: \n" + mUserListBean.getAppId());
            open_id.setText("open_id: \n" + mUserListBean.getOpenId());
            token.setText("token: \n" + mUserListBean.getToken());
        }
        int way = PreferenceUtil.getInstance().getInt(BaseApplication.KEY_INTEGRATED_WAY,0);
        if (way == 1){
            fragment_way.setChecked(false);
            activity_way.setChecked(true);
        }
        else{
            fragment_way.setChecked(true);
            activity_way.setChecked(false);
        }
    }

    @Override
    public  void onResume(){
        super.onResume();
    }


    @Override
    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
        if (buttonView.getId() == R.id.fragment_way){
            if (isChecked)
                PreferenceUtil.getInstance().putInt(BaseApplication.KEY_INTEGRATED_WAY,0);
        }
        else if (buttonView.getId() == R.id.activity_way){
            if (isChecked)
                PreferenceUtil.getInstance().putInt(BaseApplication.KEY_INTEGRATED_WAY,1);
        }
    }
}
