package com.xiaoyi;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;

import com.xiaoyi.alertui.NewAlertFragment;
import com.xiaoyi.base.KeyConst;
import com.xiaoyi.base.ui.BaseActivity;

public class AlertActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_alert);
        NewAlertFragment fragment = new NewAlertFragment();
        // to set specified device, use code below
        // PreferenceUtil.getInstance().putString(KeyConst.ALERT_MESSAGE_DEVICE_DID, info.uid)
        checkFragment(fragment,R.id.container);
    }


    private void checkFragment(Fragment fragment, int containerId) {
        if (fragment != null) {
            FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
            if (fragment.isAdded()) {
                ft.show(fragment);
            } else {
                ft.add(containerId, fragment);
            }
            ft.commitAllowingStateLoss();
        }
    }
}
