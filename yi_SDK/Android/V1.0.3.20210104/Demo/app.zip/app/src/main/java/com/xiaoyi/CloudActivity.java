package com.xiaoyi;

import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.xiaoyi.base.ui.BaseActivity;
import com.xiaoyi.cloud.newCloud.fragment.CloudVideoFragment;
import com.xiaoyi.yicamerasdkcore.YiCameraSdk;

public class CloudActivity extends AppCompatActivity implements YiCameraSdk.OnFragmentBackBtnListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cloud);
        YiCameraSdk.setOnFragmentBackBtnListener(this);
        CloudVideoFragment fragment = new CloudVideoFragment();
        checkFragment(fragment,R.id.container);
    }

    private void checkFragment(Fragment fragment, int containerId) {
        if (fragment != null) {
            FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
            if (fragment.isAdded()) {
                ft.show(fragment);
            } else {
                ft.add(containerId, fragment);
            }
            ft.commitAllowingStateLoss();
        }
    }

    @Override
    public void OnFragmentBackBtn(int type) {
        if (type == YiCameraSdk.CLOUD_VIDEO_FRAGMENT) {
            finish();
        }
    }

    @Override
    public void onBackPressed() {
        if (getResources().getConfiguration().orientation == getResources().getConfiguration().ORIENTATION_LANDSCAPE){
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        } else {
            super.onBackPressed();
        }
    }

}
