package com.xiaoyi;

import android.os.Bundle;
import android.text.TextUtils;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.xiaoyi.player.CameraSettingFragment;
import com.xiaoyi.yicamerasdkcore.YiCameraSdk;

public class CameraSettingsActivity extends AppCompatActivity implements YiCameraSdk.OnFragmentBackBtnListener{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_camera_settings_demo);

        String uid = getIntent().getStringExtra("UID");
        if (TextUtils.isEmpty(uid)){
            finish();
            return;
        }
        YiCameraSdk.setOnFragmentBackBtnListener(this);
        CameraSettingFragment fragment = CameraSettingFragment.newInstance(uid);
        checkFragment(fragment,R.id.container);
    }


    private void checkFragment(Fragment fragment, int containerId) {
        if (fragment != null) {
            FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
            if (fragment.isAdded()) {
                ft.show(fragment);
            } else {
                ft.add(containerId, fragment);
            }
            ft.commitAllowingStateLoss();
        }
    }

    @Override
    public void OnFragmentBackBtn(int type) {
        finish();
    }
}
