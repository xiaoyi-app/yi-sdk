package com.xiaoyi.bean;

import com.google.gson.annotations.Expose;

import java.io.Serializable;
import java.util.List;

public class UserListBean implements Serializable {

    /**
     * records : [{"id":2,"appId":"ZeRoj9ucmjkk2Nxc3wFjAzf6LGeBP3Ft","openId":"T8BiXYKGqoRFHsrBp8zseb04caVL0fRW","userId":3,"token":"6a6cf0bd-59df-499d-a652-790f8237444c","nickName":"Dean001","createdTime":"2020-11-02T16:01:28","updatedTime":"2020-11-02T16:01:28"}]
     * total : 1
     * size : 10
     * current : 1
     * searchCount : true
     * pages : 1
     */
    @Expose
    private int total;
    @Expose
    private int size;
    @Expose
    private int current;
    @Expose
    private boolean searchCount;
    @Expose
    private int pages;
    @Expose
    private List<RecordsBean> records;

    public int getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }

    public int getCurrent() {
        return current;
    }

    public void setCurrent(int current) {
        this.current = current;
    }

    public boolean isSearchCount() {
        return searchCount;
    }

    public void setSearchCount(boolean searchCount) {
        this.searchCount = searchCount;
    }

    public int getPages() {
        return pages;
    }

    public void setPages(int pages) {
        this.pages = pages;
    }

    public List<RecordsBean> getRecords() {
        return records;
    }

    public void setRecords(List<RecordsBean> records) {
        this.records = records;
    }

    public static class RecordsBean implements Serializable{
        /**
         * id : 2
         * appId : ZeRoj9ucmjkk2Nxc3wFjAzf6LGeBP3Ft
         * openId : T8BiXYKGqoRFHsrBp8zseb04caVL0fRW
         * userId : 3
         * token : 6a6cf0bd-59df-499d-a652-790f8237444c
         * nickName : Dean001
         * createdTime : 2020-11-02T16:01:28
         * updatedTime : 2020-11-02T16:01:28
         */
        @Expose
        private int id;
        @Expose
        private String appId;
        @Expose
        private String openId;
        @Expose
        private long userId;
        @Expose
        private String token;
        @Expose
        private String nickName;
        @Expose
        private String createdTime;
        @Expose
        private String updatedTime;

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public String getAppId() {
            return appId;
        }

        public void setAppId(String appId) {
            this.appId = appId;
        }

        public String getOpenId() {
            return openId;
        }

        public void setOpenId(String openId) {
            this.openId = openId;
        }

        public long getUserId() {
            return userId;
        }

        public void setUserId(long userId) {
            this.userId = userId;
        }

        public String getToken() {
            return token;
        }

        public void setToken(String token) {
            this.token = token;
        }

        public String getNickName() {
            return nickName;
        }

        public void setNickName(String nickName) {
            this.nickName = nickName;
        }

        public String getCreatedTime() {
            return createdTime;
        }

        public void setCreatedTime(String createdTime) {
            this.createdTime = createdTime;
        }

        public String getUpdatedTime() {
            return updatedTime;
        }

        public void setUpdatedTime(String updatedTime) {
            this.updatedTime = updatedTime;
        }
    }
}
