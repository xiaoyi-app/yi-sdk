package com.xiaoyi;

import android.Manifest;
import android.content.Context;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.text.TextUtils;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;

import com.xiaoyi.base.KeyConst;
import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.uber.autodispose.AutoDispose;
import com.xiaoyi.base.ui.BaseActivity;
import com.xiaoyi.base.util.PreferenceUtil;
import com.xiaoyi.base.util.permission.PermissionRequestListener;
import com.xiaoyi.base.util.permission.PermissionUtil;
import com.xiaoyi.player.FileProvider7;
import com.xiaoyi.bean.UserListBean;
import com.xiaoyi.http.DemoApi;
import com.xiaoyi.http.DemoHttp;
import com.xiaoyi.yicamerasdkcore.BaseResponse;
import com.xiaoyi.yicamerasdkcore.YiCameraSdk;
import com.xiaoyi.yicamerasdkcore.YiCameraSdkService;

import java.io.File;
import java.util.List;

import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.functions.Consumer;
import io.reactivex.functions.Function;
import io.reactivex.schedulers.Schedulers;

import static com.xiaoyi.yicamerasdkcore.YiCameraSdk.mOnUserVerifyListener;
import static com.xiaoyi.yicamerasdkcore.YiCameraSdkService.HTTPCODE_SUCCESS;


public class DemoActivity extends BaseActivity implements View.OnClickListener, YiCameraSdk.OnUpgradeClickedListener, YiCameraSdk.OnCameraSettingsListener, YiCameraSdk.OnBindDeviceListener {
    public static String TEST_UID = "TNPUSAK-398812-WEESZ";

    private DemoApi demoApi;
    private TextView version;
    private TextView nameTx;
    private LinearLayout nameLin;
    private Button bindDeviceBtn;
    private Button deviceListBtn;
    private Button cloudBtn;
    private Button startPlayerBtn;
    private Button startCameraPlayer;
    private Button startCameraSettings;
    private ImageView addDeviceImg;
    private String[] permissionStorageArray = new String[]{
            Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE
    };
    private UserListBean.RecordsBean mUserListBean;
    private int integratedWay = 0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo);
        demoApi = DemoHttp.retrofit.create(DemoApi.class);
        version = findViewById(R.id.version);
        nameTx = findViewById(R.id.name);
        nameLin = findViewById(R.id.nameLin);
        nameLin.setOnClickListener(this);
        bindDeviceBtn = findViewById(R.id.alert);
        bindDeviceBtn.setOnClickListener(this);
        deviceListBtn = findViewById(R.id.list);
        deviceListBtn.setOnClickListener(this);
        cloudBtn = findViewById(R.id.cloud);
        cloudBtn.setOnClickListener(this);
        startPlayerBtn = findViewById(R.id.startDevicePlayer);
        startPlayerBtn.setOnClickListener(this);
        startCameraPlayer = findViewById(R.id.startCameraPlayer);
        startCameraPlayer.setOnClickListener(this);
        startCameraSettings = findViewById(R.id.startCameraSettings);
        startCameraSettings.setOnClickListener(this);
        addDeviceImg = findViewById(R.id.ivAddCameraBlue);
        addDeviceImg.setOnClickListener(this);
        version.setText("V" + YiCameraSdk.SDK_VERSION);
        YiCameraSdk.setOnUpgradeClickedListener(this);
        YiCameraSdk.setOnCameraSettingsListener(this);
        YiCameraSdk.setOnBindDeviceListener(this);

        nameLin.setVisibility(View.VISIBLE);

        mUserListBean = (UserListBean.RecordsBean) getIntent().getSerializableExtra(UserListActivity.BUNDLE_USER_BEAN);
        if (mUserListBean != null) {
            nameTx.setText(mUserListBean.getNickName());
        } else {
            finish();
        }

    }

    @Override
    protected void onResume() {
        super.onResume();
        PermissionUtil.newInstance(this).requestPermission(this, PermissionUtil.PERMISSION_REQUEST_CODE_MAIN_INTERNATIONAL,
                permissionRequestListener, permissionStorageArray);
        integratedWay = PreferenceUtil.getInstance().getInt(BaseApplication.KEY_INTEGRATED_WAY,0);
    }

    private PermissionRequestListener permissionRequestListener = new PermissionRequestListener() {
        @Override
        public void onPermissionGranted(int requestCode) {
            if (requestCode == PermissionUtil.PERMISSION_REQUEST_CODE_MAIN_INTERNATIONAL) {
//                Intent mIntent = new Intent(MainActivity.this, AntsGalleryManagerService.class);
//                startService(mIntent);
            }
        }

        @Override
        public void onPermissionsDenied(int requestCode, List<String> deniedList) {
            if ((deniedList.contains(Manifest.permission.READ_EXTERNAL_STORAGE) &&
                    !PermissionUtil.permissionPermanentlyDenied(DemoActivity.this, Manifest.permission.READ_EXTERNAL_STORAGE)) ||
                    (deniedList.contains(Manifest.permission.WRITE_EXTERNAL_STORAGE) &&
                            !PermissionUtil.permissionPermanentlyDenied(DemoActivity.this, Manifest.permission.WRITE_EXTERNAL_STORAGE))) {
//                AppManager.getAppManager().AppExit(MainActivity.this);
                getHelper().showMessage("App needs storage to proceed");
            }

        }
    };

    @Override
    public void onClick(View v) {
        int id = v.getId();
        switch (id){
            case R.id.nameLin:
                // go to show user info
                Intent intent = new Intent(DemoActivity.this, UserInfoActivity.class);
                intent.putExtra(UserListActivity.BUNDLE_USER_BEAN, mUserListBean);
                startActivity(intent);
                break;
            case R.id.alert:
                // go to alert activity
                checkalert();
                break;
            case R.id.startDevicePlayer:
                startPlayerActivity(TEST_UID);
                break;
            case R.id.startCameraPlayer:
                checkcameraplayer();
                break;
            case R.id.startCameraSettings:
                checkcamerasettings(TEST_UID);
                break;
            case R.id.list:
                // go to device list
                checklist();
                break;
            case R.id.cloud:
                // go to cloud
                checkcloud();
                break;
            case R.id.ivAddCameraBlue:
                if(PermissionUtil.hasPermission(this, Manifest.permission.CAMERA)) {
                    // go to bind device
                    bindDevice();
                } else {
                    ActivityCompat.requestPermissions(DemoActivity.this,new String[]{Manifest.permission.CAMERA},0x112);
                }
                break;
        }
    }

    private void startPlayerActivity(String uid){
        YiCameraSdk.openCameraPlayerActivity(uid, new YiCameraSdk.YICallBack() {
            @Override
            public void onResult(int code, String result) {
                Log.e("DemoActivity", "onResult: " + result);
            }
        });
    }

    private void checkalert(){
        if (integratedWay == 1){
            YiCameraSdk.openNewAlertActivity(this);
        }
        else {
            Intent intent = new Intent(this, AlertActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
        }
    }

    private void bindDevice(){
//        YiCameraSdk.get4gInfoWithUid("TNPXGAC-311002-BKZKB", new YiCameraSdk.Callback() {
//            @Override
//            public void onResult(boolean result, String iccid) {
//                if (result){
//                    Log.e("get4gInfoWithUid",iccid);
//                }
//            }
//        });

        if (integratedWay == 1){
            //YiCameraSdk.openDeviceBindActivity(this);
            YiCameraSdk.openBindChoiceModeActivity(this);
        }
        else{
            //Intent intent = new Intent(this, OpenDeviceBindActivity.class);
            Intent intent = new Intent(this, ChoiceModeActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
        }
    }

    private void checkcloud(){
        if (integratedWay == 1){
            YiCameraSdk.openCloudVideoActivity(this);
        }
        else{
            Intent intent = new Intent(this, CloudActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
        }
    }

    private void checkcameraplayer(){
        if (integratedWay == 1){
            YiCameraSdk.openCameraPlayerActivity(TEST_UID,null);
        }
        else{
            Intent intent = new Intent(this, CameraPlayerActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
        }
    }

    private void checkcamerasettings(String uid){
        if (integratedWay == 1){
            YiCameraSdk.openCameraSettingActivity(uid,null);
        }
        else{
            Intent intent = new Intent(this, CameraSettingsActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            intent.putExtra("UID",uid);
            startActivity(intent);
        }
    }

    private void checklist(){
        if (integratedWay == 1){
            YiCameraSdk.openDeviceListActivity(this);
        }
        else {
            Intent intent = new Intent(this, DeviceActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if(grantResults[0] == PackageManager.PERMISSION_GRANTED){
            bindDevice();
        } else {
            Toast.makeText(this,"NO PERMISSION",Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public void onUpgradeClicked(String deviceId, String orderCode, int currentStatus) {
        Log.e("onUpgradeClicked==>","deviceId="+deviceId+" ,orderCode="+orderCode+" ,currentStatus="+currentStatus);
        Toast.makeText(this,"deviceId="+deviceId+" ,orderCode="+orderCode+" ,currentStatus="+currentStatus,Toast.LENGTH_SHORT).show();
//        if (mUserListBean!=null)
//            getOrderUpgrade(deviceId,mUserListBean.getUserId());
    }

    private void getOrderUpgrade(String uid,long id){
        showLoading();
        demoApi.getOrderUpgrade(uid, id)
                .onErrorReturn(new Function<Throwable, BaseResponse<String>>() {
                    @Override
                    public BaseResponse<String> apply(Throwable throwable) throws Exception {
                        return new BaseResponse<>(0, "", null);
                    }
                })
                .observeOn(AndroidSchedulers.mainThread())
                .as(AutoDispose.autoDisposable(getScopeProvider()))
                .subscribe(new Consumer<BaseResponse<String>>() {
                    @Override
                    public void accept(BaseResponse<String> response) throws Exception {
                        dismissLoading();
                    }
                }, new Consumer<Throwable>() {
                    @Override
                    public void accept(Throwable throwable) throws Exception {
                        dismissLoading();
                    }
                });
    }

    @Override
    public void OnSettingsClick(String uid) {
        checkcamerasettings(uid);
    }

    @Override
    public void OnBindDeviceResult(boolean result, String uid, String name) {
        if (result)
            Log.e("OnBindDeviceResult ==>",  "uid = " + uid + " name = " + name);
        else
            Log.e("OnBindDeviceResult ==>", "error");
    }
}
