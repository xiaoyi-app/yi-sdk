package com.xiaoyi.http;

import com.xiaoyi.bean.UserListBean;
import com.xiaoyi.bean.RefreshTokenBean;
import com.xiaoyi.yicamerasdkcore.BaseResponse;

import io.reactivex.Single;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.PUT;
import retrofit2.http.Path;
import retrofit2.http.Query;

public interface DemoApi {
    // login to get user id
    @GET("/demo/app/login")
    Single<DemoHttp.LoginInfo> login();

    // use user id and uuid to get user open id and user token
    @GET("/demo/app/user_token/{userid}/{uuid}")
    Single<BaseResponse<DemoHttp.UserData>> getUserData(@Path("userid") String userid, @Path("uuid") String uuid);

    @GET("/demo/alder/user-info/list")
    Single<BaseResponse<UserListBean>> getUserList();

    @FormUrlEncoded
    @POST("/demo/alder/user-info/save")
    Single<BaseResponse<DemoHttp.SaveUserInfo>> saveUserInfo(
            @Field("nickName") String nickName);

    @FormUrlEncoded
    @PUT("/demo/alder/user-info/edit")
    Single<BaseResponse<Object>> editUserInfo(
            @Field("id") long id,
            @Field("nickName") String nickName);

    @GET("/demo/alder/order/cancel")
    Single<BaseResponse<String>> getOrderCancel(@Query("orderCode") String orderCode,
                                                @Query("userId") long userId);

    @GET("/demo/alder/order/renew")
    Single<BaseResponse<String>> getOrderRenew(@Query("orderCode") String orderCode,
                                               @Query("userId") long userId);

    @GET("/demo/alder/order/upgrade")
    Single<BaseResponse<String>> getOrderUpgrade(@Query("uid") String uid,
                                                 @Query("userId") long userId);

    @FormUrlEncoded
    @PUT("/demo/alder/user-info/token/refresh")
    Single<BaseResponse<String>> refreshToken(
            @Field("id") long id);

    @GET("/bm/v1/user_token")
    Single<BaseResponse<RefreshTokenBean>> refreshTokenBm(@Query("appId") String appId,
                                                          @Query("openId") String openId);
}
