package com.xiaoyi.http;

import com.google.gson.GsonBuilder;
import com.google.gson.annotations.Expose;

import java.util.concurrent.TimeUnit;

import io.reactivex.schedulers.Schedulers;
import okhttp3.OkHttpClient;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Retrofit;
import retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory;
import retrofit2.converter.gson.GsonConverterFactory;

public class DemoHttp {

    public static Retrofit retrofit;
    private static OkHttpClient httpClient;


    public static void init(String baseurl){
        OkHttpClient.Builder builder = new OkHttpClient.Builder().
                connectTimeout(10, TimeUnit.SECONDS).
                writeTimeout(10, TimeUnit.SECONDS).
                readTimeout(10, TimeUnit.SECONDS);
//        if(BuildConfig.DEBUG){
            HttpLoggingInterceptor loggingInterceptor = new HttpLoggingInterceptor();
            loggingInterceptor.setLevel(HttpLoggingInterceptor.Level.BODY);
            builder.addInterceptor(loggingInterceptor);
//        }
        httpClient = builder.build();

        retrofit = new Retrofit.Builder().baseUrl(baseurl)
                .client(httpClient)
                .addConverterFactory(GsonConverterFactory.create(
                        new GsonBuilder().excludeFieldsWithoutExposeAnnotation().serializeNulls()
                                .create()))
                .addCallAdapterFactory(RxJava2CallAdapterFactory.createWithScheduler(Schedulers.io())).build();
    }

    public static class LoginInfo {
        @Expose
        public long userId;
    }

    public static class UserData {
        @Expose
        public String openId;
        @Expose
        public String token;
        @Expose
        public long expiresTime;
    }

    public static class SaveUserInfo {
        @Expose
        public String appId;
        @Expose
        public String createdTime;
        @Expose
        public String nickName;
        @Expose
        public String openId ;
        @Expose
        public String token ;
        @Expose
        public String updatedTime ;
        @Expose
        public long userId;
        @Expose
        public long id;
    }
}
