package com.xiaoyi;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;

import com.uber.autodispose.AutoDispose;
import com.xiaoyi.adapter.UserListAdapter;
import com.xiaoyi.base.ui.BaseActivity;
import com.xiaoyi.base.util.PreferenceUtil;
import com.xiaoyi.http.DemoApi;
import com.xiaoyi.http.DemoHttp;
import com.xiaoyi.yicamerasdkcore.BaseResponse;
import com.xiaoyi.yicamerasdkcore.YiCameraSdk;

import java.util.UUID;

import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.functions.Consumer;
import io.reactivex.functions.Function;

public class LoginActivity extends BaseActivity implements View.OnClickListener {
    private static final String TAG = "LoginActivity";
    Button login1, login2, login3;// for diffirent mock user id 1,2,3
    RadioButton debug,release;
    RadioButton demo_apk,release_apk;
//    DemoApi demoApi;
//    public static String URL = "https://fat1-api-us.xiaoyi.com";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        login1 = findViewById(R.id.login1);
        login2 = findViewById(R.id.login2);
        login3 = findViewById(R.id.login3);
        debug = findViewById(R.id.debug);
        release = findViewById(R.id.release);
//        // set demo http url
//        DemoHttp.init(URL);
//        demoApi = DemoHttp.retrofit.create(DemoApi.class);
        login1.setOnClickListener(this);
        login2.setOnClickListener(this);
        login3.setOnClickListener(this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        PreferenceUtil.initInstance(this);
        int url = PreferenceUtil.getInstance().getInt(BaseApplication.KEY_URL,0);
        if (url==1){
            DemoHttp.init(YiCameraSdk.RELEASE_URL);
            YiCameraSdk.setEnv(YiCameraSdk.Env.RELEASE);
            debug.setChecked(false);
            release.setChecked(true);
        }
        else{
            debug.setChecked(true);
            release.setChecked(false);
            DemoHttp.init(YiCameraSdk.SANDBOX_URL);
            YiCameraSdk.setEnv(YiCameraSdk.Env.SANDBOX);
        }
//        PreferenceUtil.initInstance(this);
//        String openid = PreferenceUtil.getInstance().getString("openId");
//        if (!TextUtils.isEmpty(openid)) {
//            Intent intent = new Intent(getBaseContext(), DemoActivity.class);
//            startActivity(intent);
//            finish();
//        }

    }

    @Override
    public void onClick(View v) {
        //showLoading();
        // first login to get user id
        // second, use userid and a uuid to get openid and token
        String userid = "123";
        switch (v.getId()) {
            case R.id.login1:
                userid = "1";
                if (release.isChecked()){
                    DemoHttp.init(YiCameraSdk.RELEASE_URL);
                    PreferenceUtil.getInstance().putInt(BaseApplication.KEY_URL,1);
                    YiCameraSdk.setEnv(YiCameraSdk.Env.RELEASE);
                }
                else{
                    DemoHttp.init(YiCameraSdk.SANDBOX_URL);
                    PreferenceUtil.getInstance().putInt(BaseApplication.KEY_URL,0);
                    YiCameraSdk.setEnv(YiCameraSdk.Env.SANDBOX);
                }
                Intent intent = new Intent(getBaseContext(), UserListActivity.class);
                startActivity(intent);
                break;
            case R.id.login2:
                userid = "2";
                break;
            case R.id.login3:
                userid = "3";
                break;
        }
//        final String uuid = YiCameraSdk.getUUID();
//        PreferenceUtil.getInstance().putString("openId","RE5eUA2hDhAgaE2AfKw4aBmbpZ3KLXvo" );
//        PreferenceUtil.getInstance().putString("token","8d102c7f-330a-4dcd-8df4-c163276b713f" );
//        PreferenceUtil.getInstance().putString("uuid", uuid);
//        demoApi.getUserData(userid, uuid)
//                .onErrorReturn(new Function<Throwable, BaseResponse<DemoHttp.UserData>>() {
//                    @Override
//                    public BaseResponse<DemoHttp.UserData> apply(Throwable throwable) throws Exception {
//                        return new BaseResponse<>(0, "", null);
//                    }
//                })
//                .observeOn(AndroidSchedulers.mainThread())
//                .as(AutoDispose.autoDisposable(getScopeProvider()))
//                .subscribe(new Consumer<BaseResponse<DemoHttp.UserData>>() {
//                    @Override
//                    public void accept(BaseResponse<DemoHttp.UserData> userDataBaseResponse) throws Exception {
//                        dismissLoading();
//                        if (userDataBaseResponse.code == 20000) {
//                            // store user info in SharedPreference
////                            PreferenceUtil.getInstance().putString("openId", userDataBaseResponse.data.openId);
////                            PreferenceUtil.getInstance().putString("token", userDataBaseResponse.data.token);
////                            PreferenceUtil.getInstance().putString("uuid", uuid);
//
//                            Intent intent = new Intent(getBaseContext(), DemoActivity.class);
//                            startActivity(intent);
//                            finish();
//                        }
//                    }
//                }, new Consumer<Throwable>() {
//                    @Override
//                    public void accept(Throwable throwable) throws Exception {
//                        dismissLoading();
//                        Intent intent = new Intent(getBaseContext(), DemoActivity.class);
//                        startActivity(intent);
//                        finish();
//                    }
//                });

    }
}
