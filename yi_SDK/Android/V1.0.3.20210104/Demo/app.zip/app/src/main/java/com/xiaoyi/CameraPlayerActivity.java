package com.xiaoyi;

import android.os.Bundle;
import android.util.Log;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import com.xiaoyi.player.StartCameraPlayerFragment;
import com.xiaoyi.yicamerasdkcore.YiCameraSdk;

public class CameraPlayerActivity extends AppCompatActivity implements YiCameraSdk.OnFragmentBackBtnListener{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_camera_player_demo);

        YiCameraSdk.setOnFragmentBackBtnListener(this);
        StartCameraPlayerFragment fragment = StartCameraPlayerFragment.newInstance(DemoActivity.TEST_UID, new YiCameraSdk.YICallBack() {
            @Override
            public void onResult(int success, String reason) {
                Log.e("CameraPlayerActivity==>",reason);
            }
        });
        checkFragment(fragment,R.id.container);
    }

    @Override
    public  void onResume(){
        super.onResume();
    }

    private void checkFragment(Fragment fragment, int containerId) {
        if (fragment != null) {
            FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
            if (fragment.isAdded()) {
                ft.show(fragment);
            } else {
                ft.add(containerId, fragment);
            }
            ft.commitAllowingStateLoss();
        }
    }

    @Override
    public void OnFragmentBackBtn(int type) {
        if (type == YiCameraSdk.CAMERA_PLAY_FRAGMENT) {
            finish();
        }
        else if (type == YiCameraSdk.CLOUD_VIDEO_FRAGMENT) {
            finish();
        }
        else if (type == YiCameraSdk.CAMERA_SETTINGS_FRAGMENT) {
            FragmentManager supportFragmentManager = getSupportFragmentManager();
            supportFragmentManager.popBackStackImmediate("CameraSettingFragment", FragmentManager.POP_BACK_STACK_INCLUSIVE);
        }
        else if (type == YiCameraSdk.CAMERA_SETTINGS_FRAGMENT_DELETE) {
            finish();
        }
    }

}
