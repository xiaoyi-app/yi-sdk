package com.xiaoyi;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.scwang.smart.refresh.layout.SmartRefreshLayout;
import com.scwang.smart.refresh.layout.api.RefreshLayout;
import com.scwang.smart.refresh.layout.listener.OnRefreshListener;
import com.uber.autodispose.AutoDispose;
import com.xiaoyi.adapter.UserListAdapter;
import com.xiaoyi.base.KeyConst;
import com.xiaoyi.base.ui.ActivityHelper;
import com.xiaoyi.base.ui.BaseActivity;
import com.xiaoyi.base.util.PreferenceUtil;
import com.xiaoyi.bean.RefreshTokenBean;
import com.xiaoyi.bean.UserListBean;
import com.xiaoyi.http.DemoApi;
import com.xiaoyi.http.DemoHttp;
import com.xiaoyi.util.DialogUtils;
import com.xiaoyi.yicamerasdkcore.BaseResponse;
import com.xiaoyi.yicamerasdkcore.YiCameraSdk;

import java.util.ArrayList;
import java.util.List;

import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.functions.Consumer;
import io.reactivex.functions.Function;

public class UserListActivity extends BaseActivity implements View.OnClickListener, OnRefreshListener ,YiCameraSdk.OnUserVerifyListener {

    public static String BUNDLE_USER_BEAN = "BUNDLE_USER_BEAN";
    private UserListAdapter mAdapter;
    private SmartRefreshLayout mRefreshLayout;
    private RecyclerView mRecyclerview;
    private Button addUserBtn;
    private List<UserListBean.RecordsBean> mList = new ArrayList<>();
    DemoApi demoApi;
    private int mPosition = 0;
    private boolean isRefresh = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_list);
        demoApi = DemoHttp.retrofit.create(DemoApi.class);
        mRefreshLayout=(SmartRefreshLayout)findViewById(R.id.mRefreshLayout);
        mRecyclerview=(RecyclerView)findViewById(R.id.mRecyclerview);
        addUserBtn=(Button)findViewById(R.id.addUserBtn);
        addUserBtn.setOnClickListener(this);

        YiCameraSdk.setOnUserVerifyListener(this);
        LinearLayoutManager layoutManager=new LinearLayoutManager(this);
        layoutManager.setOrientation(GridLayoutManager.VERTICAL);
        mRecyclerview.setLayoutManager(layoutManager);
        mRefreshLayout.setEnableLoadMore(false);
        mRefreshLayout.setOnRefreshListener(this);
        mAdapter = new UserListAdapter(this);
        mRecyclerview.setAdapter(mAdapter);
        mAdapter.setItemClickListener(new UserListAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(View view, int position) {
                mPosition = position;
                if (mList.get(position)!=null) {
                    showLoading();
                    isRefresh = false;
                    YiCameraSdk.userid = mList.get(mPosition).getUserId();
                    YiCameraSdk.init(getApplication(), mList.get(position).getAppId());
                    YiCameraSdk.setUserInfo(mList.get(position).getOpenId(), mList.get(position).getToken());
                }
            }

            @Override
            public void onItemLongClick(View view, int position) {
                PreferenceUtil.initInstance(UserListActivity.this);
                int url = PreferenceUtil.getInstance().getInt(BaseApplication.KEY_URL,0);
                if (url==1){
                    return;
                }
                if (mList.get(position)!=null) {
                    String nickName = mList.get(position).getNickName();
                    long id = mList.get(position).getId();
                    DialogUtils.getInstance().showDialog(UserListActivity.this,
                            getString(R.string.dialog_edit_new_hint),
                            nickName,
                            getString(R.string.dialog_edit_new_hint),
                            getString(R.string.dialog_btn));
                    DialogUtils.getInstance().setOnClickDialogListener(new DialogUtils.OnClickDialogListener() {
                        @Override
                        public void onResult(String editValue, boolean sure) {
                            if (sure) {
                                if (TextUtils.isEmpty(editValue)) {
                                    Toast.makeText(UserListActivity.this, "The name can not be empty", Toast.LENGTH_SHORT).show();
                                    return;
                                }
                                editUserInfo(id, editValue);
                            }

                        }
                    });
                }
            }
        });

        mRefreshLayout.autoRefresh();
    }

    @Override
    public  void onResume(){
        super.onResume();
    }

    @Override
    public void onRefresh(@NonNull RefreshLayout refreshLayout) {
        mList.clear();
        mAdapter.setList(mList);

        PreferenceUtil.initInstance(this);
        int url = PreferenceUtil.getInstance().getInt(BaseApplication.KEY_URL,0);
        if (url==1){
            addUserBtn.setVisibility(View.GONE);
            UserListBean.RecordsBean bean = new UserListBean.RecordsBean();
//            bean.setToken("7edc0071-7cca-4ea5-9dfc-30bee52cd251");
//            bean.setOpenId("RE5eUA2hDhAgaE2AfKw4aBmbpZ3KLXvo");
//            bean.setAppId("3Idw0k0OG5QGiGVlsnn8bAEFCwVxkrCm");

            bean.setToken("d12b79f4-02b6-4429-817e-fda59f9f42f1");
            //bean.setOpenId("Q2elhCw2CgO0nPSHVsctaPGKdf64a6Yx");
            bean.setOpenId("I88G9zIZBmKLVA7xh9WKw01lu26zW8Sm");
            bean.setAppId("Bib82JkvvtC4eCUuI2d7zzSBfAFpCcW3");
            bean.setNickName("Release Account");
            mList.add(bean);
            mAdapter.setList(mList);
            mRefreshLayout.finishRefresh();
            mRefreshLayout.resetNoMoreData();
        }
        else{
            addUserBtn.setVisibility(View.GONE);
            UserListBean.RecordsBean bean = new UserListBean.RecordsBean();
            bean.setToken("d12b79f4-02b6-4429-817e-fda59f9f42f1");
            //bean.setOpenId("Q2elhCw2CgO0nPSHVsctaPGKdf64a6Yx");
            bean.setOpenId("I88G9zIZBmKLVA7xh9WKw01lu26zW8Sm");
            bean.setAppId("Bib82JkvvtC4eCUuI2d7zzSBfAFpCcW3");
            bean.setNickName("Debug Account");
            mList.add(bean);
            mAdapter.setList(mList);
            mRefreshLayout.finishRefresh();
            mRefreshLayout.resetNoMoreData();
//            addUserBtn.setVisibility(View.VISIBLE);
//            getUserList();
        }
//        refreshLayout.getLayout().postDelayed(new Runnable() {
//            @Override
//            public void run() {
//                refreshLayout.finishRefresh();
//                refreshLayout.resetNoMoreData();
//            }
//        }, 2000);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.addUserBtn:{
                DialogUtils.getInstance().showDialog(UserListActivity.this,
                        getString(R.string.dialog_edit_hint),
                        "",
                        getString(R.string.dialog_edit_hint),
                        getString(R.string.dialog_btn));
                DialogUtils.getInstance().setOnClickDialogListener(new DialogUtils.OnClickDialogListener() {
                    @Override
                    public void onResult(String editValue, boolean sure) {
                        if (sure) {
                            if (TextUtils.isEmpty(editValue)) {
                                Toast.makeText(UserListActivity.this, "The name can not be empty", Toast.LENGTH_SHORT).show();
                                return;
                            }
                            saveUserInfo(editValue);
                        }

                    }
                });
                break;
            }
        }
    }


    private void getUserList(){
        demoApi.getUserList()
                .onErrorReturn(new Function<Throwable, BaseResponse<UserListBean>>() {
                    @Override
                    public BaseResponse<UserListBean> apply(Throwable throwable) throws Exception {
                        return new BaseResponse<>(0, "", null);
                    }
                })
                .observeOn(AndroidSchedulers.mainThread())
                .as(AutoDispose.autoDisposable(getScopeProvider()))
                .subscribe(new Consumer<BaseResponse<UserListBean>>() {
                    @Override
                    public void accept(BaseResponse<UserListBean> userDataBaseResponse) throws Exception {
                        if (userDataBaseResponse.code == 20000) {
                            if (userDataBaseResponse.data!=null && userDataBaseResponse.data.getRecords()!=null) {
                                mList.clear();
                                mList.addAll(userDataBaseResponse.data.getRecords());
                                mAdapter.setList(mList);
                            }
                        }
                        mRefreshLayout.finishRefresh();
                        mRefreshLayout.resetNoMoreData();
                    }
                }, new Consumer<Throwable>() {
                    @Override
                    public void accept(Throwable throwable) throws Exception {
                        mRefreshLayout.finishRefresh();
                        mRefreshLayout.resetNoMoreData();
                    }
                });
    }

    private void saveUserInfo(String nickName){
        showLoading();
        demoApi.saveUserInfo(nickName)
                .onErrorReturn(new Function<Throwable, BaseResponse<DemoHttp.SaveUserInfo>>() {
                    @Override
                    public BaseResponse<DemoHttp.SaveUserInfo> apply(Throwable throwable) throws Exception {
                        return new BaseResponse<>(0, "", null);
                    }
                })
                .observeOn(AndroidSchedulers.mainThread())
                .as(AutoDispose.autoDisposable(getScopeProvider()))
                .subscribe(new Consumer<BaseResponse<DemoHttp.SaveUserInfo>>() {
                    @Override
                    public void accept(BaseResponse<DemoHttp.SaveUserInfo> userDataBaseResponse) throws Exception {
                        dismissLoading();
                        if (userDataBaseResponse.code == 20000) {
                            Toast.makeText(UserListActivity.this, "Add User Success", Toast.LENGTH_SHORT).show();
                            getUserList();
                        }
                    }
                }, new Consumer<Throwable>() {
                    @Override
                    public void accept(Throwable throwable) throws Exception {
                        dismissLoading();
                        if (throwable!=null)
                            Toast.makeText(UserListActivity.this, throwable.getMessage().toString(), Toast.LENGTH_SHORT).show();
                    }
                });
    }

    private void editUserInfo(long id, String nickName){
        showLoading();
        demoApi.editUserInfo(id, nickName)
                .onErrorReturn(new Function<Throwable, BaseResponse<Object>>() {
                    @Override
                    public BaseResponse<Object> apply(Throwable throwable) throws Exception {
                        return new BaseResponse<>(0, "", null);
                    }
                })
                .observeOn(AndroidSchedulers.mainThread())
                .as(AutoDispose.autoDisposable(getScopeProvider()))
                .subscribe(new Consumer<BaseResponse<Object>>() {
                    @Override
                    public void accept(BaseResponse<Object> userDataBaseResponse) throws Exception {
                        dismissLoading();
                        if (userDataBaseResponse.code == 20000) {
                            Toast.makeText(UserListActivity.this, "Edit User Name Success", Toast.LENGTH_SHORT).show();
                            getUserList();
                        }
                    }
                }, new Consumer<Throwable>() {
                    @Override
                    public void accept(Throwable throwable) throws Exception {
                        dismissLoading();
                        if (throwable!=null)
                            Toast.makeText(UserListActivity.this, throwable.getMessage().toString(), Toast.LENGTH_SHORT).show();
                    }
                });
    }


    private void refreshTokenBm(String appId, String openId){
        showLoading();
        demoApi.refreshTokenBm(appId, openId)
                .onErrorReturn(new Function<Throwable, BaseResponse<RefreshTokenBean>>() {
                    @Override
                    public BaseResponse<RefreshTokenBean> apply(Throwable throwable) throws Exception {
                        return new BaseResponse<>(0, "", null);
                    }
                })
                .observeOn(AndroidSchedulers.mainThread())
                .as(AutoDispose.autoDisposable(getScopeProvider()))
                .subscribe(new Consumer<BaseResponse<RefreshTokenBean>>() {
                    @Override
                    public void accept(BaseResponse<RefreshTokenBean> response) throws Exception {
                        dismissLoading();
                        if (response != null && response.data!=null){
                            Log.d("refreshToken==>",response.data.getToken());
                            mList.get(mPosition).setToken(response.data.getToken());
                            //YiCameraSdk.setUserInfo("Q2elhCw2CgO0nPSHVsctaPGKdf64a6Yx", response.data.getToken());
                            YiCameraSdk.setUserInfo("I88G9zIZBmKLVA7xh9WKw01lu26zW8Sm", response.data.getToken());

//                            mList.get(mPosition).setToken(response.data);
//                            YiCameraSdk.userid = mList.get(mPosition).getUserId();
//                            YiCameraSdk.setUserInfo(mList.get(mPosition).getOpenId(), mList.get(mPosition).getToken());
                        }
                    }
                }, new Consumer<Throwable>() {
                    @Override
                    public void accept(Throwable throwable) throws Exception {
                        dismissLoading();
                    }
                });
    }

    @Override
    public void OnUserVerifyResult(boolean result, int code) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (result){
                    dismissLoading();
                    Intent intent = new Intent(UserListActivity.this, DemoActivity.class);
                    intent.putExtra(BUNDLE_USER_BEAN, mList.get(mPosition));
                    startActivity(intent);
                }
                else{//校验失败，刷新token
                    if (!isRefresh) {
                        isRefresh=true;
                        //refreshTokenBm("Bib82JkvvtC4eCUuI2d7zzSBfAFpCcW3","Q2elhCw2CgO0nPSHVsctaPGKdf64a6Yx");
                        refreshTokenBm("Bib82JkvvtC4eCUuI2d7zzSBfAFpCcW3","I88G9zIZBmKLVA7xh9WKw01lu26zW8Sm");

                        //refreshToken(mList.get(mPosition).getId());
                    }
                    else {
                        dismissLoading();
                        isRefresh=false;
                        Toast.makeText(UserListActivity.this, "User verify failed", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }

}
