package com.xiaoyi;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.alibaba.android.arouter.facade.annotation.Route;
import com.xiaoyi.base.ui.SimpleBarRootActivity;
import com.xiaoyi.bindcamera.OpenChoiceModeFragment;
import com.xiaoyi.yicamerasdkcore.YiCameraSdk;

public class ChoiceModeActivity extends SimpleBarRootActivity implements YiCameraSdk.OnFragmentBackBtnListener {

    private OpenChoiceModeFragment openChoiceModeFragment;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choice_mode);

        setTitle(com.xiaoyi.yicamerasdkcore.bindcamera.R.string.choice_mode);
        YiCameraSdk.setOnFragmentBackBtnListener(this);
        openChoiceModeFragment = new OpenChoiceModeFragment();
        checkFragment(openChoiceModeFragment, R.id.container);
    }

    private void checkFragment(Fragment fragment, int containerId) {
        if (fragment != null) {
            FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
            if (fragment.isAdded()) {
                ft.show(fragment);
            } else {
                ft.add(containerId, fragment);
            }
            ft.commitAllowingStateLoss();
        }
    }

    @Override
    public void OnFragmentBackBtn(int type) {
        if (type == YiCameraSdk.BIND_CHOICE_MODE_FRAGMENT){
            finish();
        }
    }
}
