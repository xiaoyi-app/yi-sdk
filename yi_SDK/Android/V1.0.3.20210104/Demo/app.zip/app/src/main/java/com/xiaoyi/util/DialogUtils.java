package com.xiaoyi.util;

import android.content.Context;
import android.graphics.Color;
import android.text.Spannable;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.TextUtils;
import android.text.method.LinkMovementMethod;
import android.text.style.ClickableSpan;
import android.text.style.ForegroundColorSpan;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.kongzue.dialog.interfaces.OnMenuItemClickListener;
import com.kongzue.dialog.util.DialogSettings;
import com.kongzue.dialog.v3.BottomMenu;
import com.kongzue.dialog.v3.CustomDialog;
import com.xiaoyi.R;


public class DialogUtils {
    private static DialogUtils instance = null;

    public static DialogUtils getInstance() {
        synchronized(Object.class){
            if (instance == null) {
                instance = new DialogUtils();
            }
        }
        return instance;
    }

    /**
     * 普通对话框
     */
    private OnClickDialogListener mClickDialogListener;
    public interface OnClickDialogListener {
        void onResult(String editValue, boolean sure);
    }
    public void setOnClickDialogListener(OnClickDialogListener listener) {
        mClickDialogListener = listener;
    }

    //选择对话框
    public void showDialog(Context ctx,String title, String message){
        showDialog(ctx,title, message,"","",
                ctx.getString(R.string.dialog_btn),
                ctx.getString(R.string.dialog_cancel),
                false,
                true);
    }

    //隐藏取消按钮的选择对话框
    public void showDialog(Context ctx,String title, String message,boolean isCancelHidden, boolean isCancelable){
        showDialog(ctx,title, message,"","",
                ctx.getString(R.string.dialog_btn),
                ctx.getString(R.string.dialog_cancel),
                isCancelHidden,
                isCancelable);
    }

    //输入对话框
    public void showDialog(Context ctx,String title, String editText, boolean isCancelable){
        showDialog(ctx,title, "",editText,ctx.getString(R.string.dialog_edit_hint),
                ctx.getString(R.string.dialog_btn),
                ctx.getString(R.string.dialog_cancel),
                false,
                isCancelable);
    }
    //输入+可设置输入框hint+可设置确定按钮对话框
    public void showDialog(Context ctx,String title, String editText, String ediHint, String okText){
        showDialog(ctx,title, "",editText,ediHint,
                okText,
                ctx.getString(R.string.dialog_cancel),
                false,
                true);
    }

    private int inputType= 0;
    public void setEditViewInputType(int type){
        inputType=type;
    }

    public void showDialog(Context ctx,String title, String message, String editText,String editHint,
                                 String ok, String cancel, boolean isCancelHidden, boolean isCancelable){
        CustomDialog.build((AppCompatActivity) ctx, R.layout.dialog_admin, new CustomDialog.OnBindView() {
            @Override
            public void onBind(final CustomDialog dialog, View v) {
                TextView titleView = v.findViewById(R.id.dialog_title);
                TextView messageView  = v.findViewById(R.id.dialog_message);
                EditText editView  = v.findViewById(R.id.dialog_edit);
                if (inputType!=0)
                    editView.setInputType(inputType);
                titleView.setText(title);
                messageView.setText(message);
                if ((!TextUtils.isEmpty(editText))||(!TextUtils.isEmpty(editHint))){
                    messageView.setVisibility(View.GONE);
                    editView.setVisibility(View.VISIBLE);
                    editView.setHint(editHint);
                    editView.setText(editText);
                }
                Button btnOk = v.findViewById(R.id.dialog_btn);
                btnOk.setText(ok);
                btnOk.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (mClickDialogListener!=null){
                            mClickDialogListener.onResult(editView.getText().toString(),true);
                        }
                        if (!TextUtils.isEmpty(editText)||!TextUtils.isEmpty(editHint)) {
                            if (!TextUtils.isEmpty(editView.getText().toString()))
                                dialog.doDismiss();
                        }
                        else{
                            dialog.doDismiss();
                        }
                    }
                });

                Button btnCancel = v.findViewById(R.id.dialog_cancel);
                btnCancel.setText(cancel);
                if (isCancelHidden)
                    btnCancel.setVisibility(View.GONE);
                btnCancel.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        dialog.doDismiss();
                        if (mClickDialogListener!=null){
                            mClickDialogListener.onResult(editView.getText().toString(),false);
                        }
                    }
                });
            }
        }).setAlign(CustomDialog.ALIGN.DEFAULT).setCancelable(isCancelable).show();
    }


    /**
     * 底部选择对话框
     */
    private OnBottomDialogListener mBottomDialogListener;
    public interface OnBottomDialogListener {
        void onClick(String text, int index);
    }
    public void setOnBottomDialogListener(OnBottomDialogListener listener) {
        mBottomDialogListener = listener;
    }
    //底部选择对话框
    public void showBottomDialog(Context ctx,String[] menus){
        DialogSettings.style = DialogSettings.STYLE.STYLE_MATERIAL;
        BottomMenu.show((AppCompatActivity) ctx, menus, new OnMenuItemClickListener() {
            @Override
            public void onClick(String text, int index) {
                if (mBottomDialogListener!=null){
                    mBottomDialogListener.onClick(text,index);
                }
            }
        });
    }
}
