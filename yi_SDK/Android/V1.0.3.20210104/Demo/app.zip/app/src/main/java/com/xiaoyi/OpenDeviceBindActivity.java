package com.xiaoyi;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.xiaoyi.bindcamera.OpenDeviceBindFragment;
import com.xiaoyi.yicamerasdkcore.YiCameraSdk;

public class OpenDeviceBindActivity extends AppCompatActivity implements YiCameraSdk.OnFragmentBackBtnListener{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_open_device_bind);
        OpenDeviceBindFragment fragment = new OpenDeviceBindFragment();
        checkFragment(fragment,R.id.container);

        YiCameraSdk.setOnFragmentBackBtnListener(this);
    }

    private void checkFragment(Fragment fragment, int containerId) {
        if (fragment != null) {
            FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
            if (fragment.isAdded()) {
                ft.show(fragment);
            } else {
                ft.add(containerId, fragment);
            }
            ft.commitAllowingStateLoss();
        }
    }

    @Override
    public void OnFragmentBackBtn(int type) {
        finish();
    }
}
