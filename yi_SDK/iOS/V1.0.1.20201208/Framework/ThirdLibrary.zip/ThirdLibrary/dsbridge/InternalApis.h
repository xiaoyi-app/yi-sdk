#import <Foundation/Foundation.h>
#import "DWKWebView.h"

@interface InternalApis : NSObject
@property (nullable, nonatomic, weak) DWKWebView* webview;
@end


