//
//  YICameraSDK.h
//  YICameraSDK
//
//  Created by zhangyong on 2020/3/18.
//  Copyright © 2020 zhang yong. All rights reserved.
//  sdk interfaces

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface YICameraSDK : NSObject

/// Registration platform
/// @param appId appId
+ (void)registPlatform:(NSString *)appId;

/// Get device online with deviceId
/// @param deviceId device id
+ (BOOL)getDeviceIsOnline:(NSString *)deviceId;

/// Binding user information
/// @param openId openId
/// @param userToken userToken
/// @param completeBlock success errorCode
+ (void)setUserInfo:(NSString *)openId token:(NSString *)userToken complete:(nullable void (^)(BOOL success, NSString * _Nullable errorCode))completeBlock;

/// Open the bound device page
/// @param currentController Current controller
+ (void)openDeviceBindViewComtroller:(UIViewController *)currentController;

/// Open the device list page
/// @param currentController Current controller
+ (void)openDeviceListViewController:(UIViewController *)currentController;

/// Open alarm message list page
/// @param currentController Current controller
+ (void)openAlsertsViewController:(UIViewController *)currentController;

/// Open play page based on device uid
/// @param currentController Current controller
/// @param uid device uid
/// @param completeBlock result
+ (void)openCameraPlayViewController:(UIViewController *)currentController uid:(NSString *)uid complete:(nullable void (^)(BOOL isOpenSuccess, NSString *errorMessage))completeBlock;

/// Open camera set page based on device uid
/// @param currentController Current controller
/// @param uid device uid
/// @param completeBlock result
+ (void)openCameraSetViewController:(UIViewController *)currentController uid:(NSString *)uid complete:(nullable void (^)(BOOL isOpenSuccess, NSString *errorMessage))completeBlock;

/// Open alarm details page based on device uid
/// @param currentController Current controller
/// @param uid device uid
/// @param alramTime Timestamp
/// @param completeBlock result
+ (void)openDeviceAlarmViewController:(UIViewController *)currentController uid:(NSString *)uid alramTime:(double)alramTime complete:(nullable void (^)(BOOL isOpenSuccess, NSString *errorMessage))completeBlock;

/// Get device list data
/// @param successBlcok Successfully returned device json data
/// @param failureBlcok Failed return
+ (void)getDeviceList:(nullable void (^) (id _Nullable responseObject))successBlock failure:(nullable void (^)(NSString * _Nullable errorCode))failureBlock;

/// Upgrade Click
/// @param deviceBlock deviceId , orderCode, upgrade status, current controller
+ (void)getUpgradeClick:(nullable void (^)(NSString * _Nullable deviceId, NSString * _Nullable orderCode, NSInteger currentStatus, UIViewController * _Nonnull currentController))deviceBlock;

/// Open Cloud page
/// @param currentController Current controller
+ (void)openCloudViewController:(UIViewController *)currentController;

/// get 4g sim info
/// @param uid device uid
/// @param block iccid Block
+ (void)get4gInfoWithUid:(NSString *_Nonnull)uid iccidBlock:(nullable void(^)(NSString * _Nullable iccid, BOOL success))block;

/// Bind device result
/// @param block uid name
+ (void)onBindDeviceResult:(void(^)(BOOL success, NSString *uid, NSString *name))block;

@end

NS_ASSUME_NONNULL_END



