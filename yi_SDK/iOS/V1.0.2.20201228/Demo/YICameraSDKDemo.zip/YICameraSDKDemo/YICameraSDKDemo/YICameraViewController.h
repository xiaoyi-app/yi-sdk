//
//  YICameraViewController.h
//  YICameraSDKDemo
//
//  Created by zhangyong on 2020/5/7.
//  Copyright © 2020 zhang yong. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface YICameraViewController : UIViewController

@end

NS_ASSUME_NONNULL_END
