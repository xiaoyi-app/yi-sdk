//
//  AlderViewController.m
//  YICameraSDKDemo
//
//  Created by zhangyong on 2020/5/7.
//  Copyright © 2020 zhang yong. All rights reserved.
//

#import "YICameraViewController.h"
#import <YICameraSDK/YICameraSDK.h>
@interface YICameraViewController ()

@end

@implementation YICameraViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    NSArray *titleArr = @[@"Add Device", @"Device List", @"Message List"];
    for (int i = 0; i < titleArr.count; i ++) {
        UIButton *btn = [[UIButton alloc] initWithFrame:CGRectMake(100, 100 + ((50 + 30) * i), 150, 50)];
        [self.view addSubview:btn];
        btn.backgroundColor = [UIColor orangeColor];
        btn.titleLabel.font = [UIFont boldSystemFontOfSize:16];
        [btn setTitle:titleArr[i] forState:UIControlStateNormal];
        [btn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        btn.tag = (i + 1) * 100;
        [btn addTarget:self action:@selector(btnClick:) forControlEvents:UIControlEventTouchUpInside];
    }
    
    [YICameraSDK onBindDeviceResult:^(BOOL success, NSString * _Nonnull uid, NSString * _Nonnull name) {
        NSLog(@"绑定设备回调 设备id：%@ 设备名称：%@", uid, name);
    }];
}

- (void)btnClick:(UIButton *)button {
    switch (button.tag) {
        case 100:
        {
            // add
            [YICameraSDK openDeviceBindViewComtroller:self];
        }
            break;

        case 200:
        {
            // device
            [YICameraSDK openDeviceListViewController:self];
        }
            break;

        case 300:
        {
            // message
            [YICameraSDK openAlsertsViewController:self];
        }
            break;

        default:
            break;
    }
}

@end
