//
//  ViewController.m
//  YICameraSDKDemo
//
//  Created by zhangyong on 2020/3/24.
//  Copyright © 2020 zhang yong. All rights reserved.
//

#import "ViewController.h"
#import <YICameraSDK/YICameraSDK.h>
#import "YICameraViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    
    // production test
    UIButton *btn = [[UIButton alloc] initWithFrame:CGRectMake(100, 100, 200, 80)];
    [self.view addSubview:btn];
    btn.backgroundColor = [UIColor blueColor];
    btn.titleLabel.font = [UIFont boldSystemFontOfSize:16];
    [btn setTitle:@"YICamaraSDK Click" forState:UIControlStateNormal];
    [btn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [btn addTarget:self action:@selector(testClick) forControlEvents:UIControlEventTouchUpInside];
}

//
- (void)testClick {
    // 测试用户信息，用户方需要从对接的接口获取
    // 演示设置sdk用户信息
    [YICameraSDK registPlatform:@"Bib82JkvvtC4eCUuI2d7zzSBfAFpCcW3"];
    [YICameraSDK setUserInfo:@"Q2elhCw2CgO0nPSHVsctaPGKdf64a6Yx" token:@"890990b6-6868-42e7-94c8-06ef12b04c62" complete:^(BOOL success, NSString *errorCode) {        NSLog(@"用户信息校验结果：%@", success ? @"成功" : @"失败");
    }];

    YICameraViewController *vc = [[YICameraViewController alloc] init];
    [self.navigationController pushViewController:vc animated:true];
}

@end


