//
//  ViewController.h
//  YICameraSDKDemo
//
//  Created by zhangyong on 2020/3/24.
//  Copyright © 2020 zhang yong. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

